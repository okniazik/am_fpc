<?php

/**
 * @author Amasty Team
 * @copyright Copyright (c) 2017 Amasty (https://www.amasty.com)
 * @package Amasty_Fpccrawler
 */
class Amasty_Fpccrawler_Model_Log extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        $this->_init('amfpccrawler/log');
    }
}
